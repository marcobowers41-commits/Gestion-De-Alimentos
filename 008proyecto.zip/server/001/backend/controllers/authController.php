<?php

require_once __DIR__ . '/../services/authService.php';

class AuthController
{
    private AuthService $authService;

    public function __construct(AuthService $authService)
    {
        $this->authService = $authService;
        
    }

    public function register(
        string $usuario,
        string $nombreCompleto,
        string $email,
        string $password,
        string $confirmPassword,
        int $cantidadFamiliares
    ): array {
        return $this->authService->register(
            $usuario,
            $nombreCompleto,
            $email,
            $password,
            $confirmPassword,
            $cantidadFamiliares
        );
    }

    public function login(
        string $email,
        string $password,
    ): array {
        return $this->authService->login(
            $email,
            $password
        );
    }
}

?>