document.addEventListener('DOMContentLoaded', () => {
  // Buscamos todos los formularios que queremos procesar con AJAX
  const ajaxForms = document.querySelectorAll('.ajax-form');
  
  ajaxForms.forEach(form => {
    form.addEventListener('submit', async (e) => {
      e.preventDefault(); // Evita la recarga de página por defecto
      
      const url = form.getAttribute('action'); // Ej: "login.php"
      const method = form.getAttribute('method') || 'POST';
      const redirectUrl = form.getAttribute('data-redirect'); // A dónde ir si hay éxito
      const errorMsg = form.parentElement.querySelector('.error-msg');
      
      // Ocultar mensaje de error anterior
      if (errorMsg) errorMsg.style.display = 'none';
      
      try {
        const formData = new FormData(form);
        
        // Petición al backend PHP
        const response = await fetch(url, {
          method: method,
          body: formData
        });
        
        // Asumimos que PHP devuelve un JSON como { "success": true } o { "success": false, "message": "..." }
        const data = await response.json();
        
        if (data.success) {
          // Si el servidor confirma éxito, redirigimos
          window.location.href = redirectUrl;
        } else {
          // Si el servidor rechaza, mostramos el mensaje de error de PHP
          if (errorMsg) {
            errorMsg.textContent = data.message || "*Los datos ingresados son incorrectos*";
            errorMsg.style.display = 'block';
          }
        }
      } catch (error) {
        console.error("Error al procesar el formulario:", error);
        
        // NOTA TEMPORAL PARA DESARROLLO FRONTEND: 
        // Como aún no tenemos los archivos PHP reales (darán error 404), 
        // simularemos el éxito para que puedas seguir navegando las maquetas.
        // Cuando el PHP esté listo, puedes borrar este bloque catch o cambiarlo.
        
        console.log("Simulando éxito de PHP (solo desarrollo)...");
        window.location.href = redirectUrl;
      }
    });
  });
});
