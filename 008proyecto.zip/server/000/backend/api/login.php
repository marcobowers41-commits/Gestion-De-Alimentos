<?php

header('Content-Type: application/json; charset=utf-8');

require_once __DIR__ . '/../config/dataBase.php';
require_once __DIR__ . '/../controllers/authController.php';
require_once __DIR__ . '/../services/authService.php';
require_once __DIR__ . '/../repositories/userRepository.php';

$userRepository = new UserRepository($conn);
$authService = new AuthService($userRepository);
$authController = new AuthController($authService);


$email = trim($_POST['email'] ?? '');
$password = $_POST['password'] ?? '';


$response = $authController->login(
    $email,
    $password
);

echo json_encode($response);

?>