const registerForm = document.getElementById("registerForm");

registerForm.addEventListener("submit", async (event) => {
  event.preventDefault();

    console.log("a");

  const data=new FormData(registerForm);

  try {
    const response = await fetch("./backend/api/register.php", {
      method: "POST",
      body: data
    });

    const resultado = await response.json();

    if (resultado.status === "success") {
        console.log("Iniciando sesión.");

        // Redirigir después de iniciar sesión
        //window.location.href = "4-family.html";
    }
    else {
        console.log(resultado.message);
      }
    }catch (error) {
      console.error(error);
      console.log("Error al conectar con el servidor.");
    }

});

console.log("A")